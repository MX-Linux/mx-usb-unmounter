<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <location filename="../mainwindow.cpp" line="94"/>
        <location filename="../mainwindow.cpp" line="203"/>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>MX USB Unmounter</source>
        <translation>MX Desmontador de USB</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="52"/>
        <source>Double-Click to Unmount</source>
        <translation>Doble clic para desmontar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="419"/>
        <source>Volume</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <location filename="../mainwindow.cpp" line="454"/>
        <source>No Removable Device</source>
        <translation>Sin dispositivo extraíble</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="98"/>
        <source>Other partitions still mounted on device</source>
        <translation>Otras particiones aún están montadas en el dispositivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <source>Unmounting %1</source>
        <translation>Desmontando %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="97"/>
        <source>%1 is Safe to Remove</source>
        <translation>Es seguro extraer %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Unable to unmount, device in use</source>
        <translation>No se puede desmontar, dispositivo en uso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="159"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="160"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>List Devices</source>
        <translation>Listar dispositivos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="162"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="169"/>
        <location filename="../mainwindow.cpp" line="246"/>
        <location filename="../mainwindow.cpp" line="252"/>
        <source>Always show icon</source>
        <translation>Mostrar siempre el icono</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="169"/>
        <location filename="../mainwindow.cpp" line="249"/>
        <source>Hide icon when not in use</source>
        <translation>Ocultar el icono cuando no se utiliza</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <source>Autostart has been disabled.</source>
        <translation>Se ha deshabilitado el inicio automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <source>Failed to disable autostart.</source>
        <translation>No se ha podido deshabilitar el inicio automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="231"/>
        <source>Autostart Disabled</source>
        <translation>Deshabilitar Inicio Automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="232"/>
        <source>Enable Autostart</source>
        <translation>Habilitar Inicio Automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="235"/>
        <source>Autostart has been enabled.</source>
        <translation>Se ha habilitado el inicio automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="235"/>
        <source>Failed to enable autostart.</source>
        <translation>No se ha podido habilitar el inicio automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Autostart Enabled</source>
        <translation>Inicio Automático Habilitado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Disable Autostart</source>
        <translation>Deshabilitar Inicio Automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="192"/>
        <source>Unmount</source>
        <translation>Desmontar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="342"/>
        <source>About MX USB Unmounter</source>
        <translation>Acerca de MX Desmontador de USB</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Quickly Unmount Removable Media</source>
        <translation>Desmontar rápidamente los medios extraíbles</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="247"/>
        <source>Application icon will stay visible all the time.</source>
        <translation>El icono de la aplicación permanecerá visible todo el tiempo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="255"/>
        <source>Application icon is now hidden and will reappear when a new device is connected.</source>
        <translation>El icono de la aplicación ahora está oculto y volverá a aparecer cuando se conecte un nuevo dispositivo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>Application icon will be hidden when there are no devices plugged in.</source>
        <translation>El icono de la aplicación se ocultará cuando no haya dispositivos conectados.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Icon Visibility</source>
        <translation>Visibilidad de iconos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="340"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de Autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="344"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="40"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="41"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
</context>
</TS>