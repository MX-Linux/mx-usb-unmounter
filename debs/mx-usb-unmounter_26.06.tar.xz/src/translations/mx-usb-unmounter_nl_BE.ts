<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl_BE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <location filename="../mainwindow.cpp" line="94"/>
        <location filename="../mainwindow.cpp" line="203"/>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>MX USB Unmounter</source>
        <translation>MX USB Ontkoppelaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="52"/>
        <source>Double-Click to Unmount</source>
        <translation>Dubbel-Klik om te Ontkoppelen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="419"/>
        <source>Volume</source>
        <translation>Deel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <location filename="../mainwindow.cpp" line="454"/>
        <source>No Removable Device</source>
        <translation>Geen Verwijderbaar Apparaat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="98"/>
        <source>Other partitions still mounted on device</source>
        <translation>Andere partities nog gekoppeld aan apparaat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <source>Unmounting %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="97"/>
        <source>%1 is Safe to Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Unable to unmount, device in use</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="159"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="160"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>List Devices</source>
        <translation>Lijst Apparaten</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="162"/>
        <source>Quit</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="169"/>
        <location filename="../mainwindow.cpp" line="246"/>
        <location filename="../mainwindow.cpp" line="252"/>
        <source>Always show icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="169"/>
        <location filename="../mainwindow.cpp" line="249"/>
        <source>Hide icon when not in use</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <source>Autostart has been disabled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <source>Failed to disable autostart.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="231"/>
        <source>Autostart Disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="232"/>
        <source>Enable Autostart</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="235"/>
        <source>Autostart has been enabled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="235"/>
        <source>Failed to enable autostart.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Autostart Enabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Disable Autostart</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="192"/>
        <source>Unmount</source>
        <translation>Ontkoppelen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="342"/>
        <source>About MX USB Unmounter</source>
        <translation>Over MX Ontkoppelaar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Quickly Unmount Removable Media</source>
        <translation>Verwijderbare Media Snel Ontkoppelen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="247"/>
        <source>Application icon will stay visible all the time.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="255"/>
        <source>Application icon is now hidden and will reappear when a new device is connected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>Application icon will be hidden when there are no devices plugged in.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Icon Visibility</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="340"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="344"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="40"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="41"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
</context>
</TS>